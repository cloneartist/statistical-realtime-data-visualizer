package com.stackroute.dataanalyticsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataAnalyticsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataAnalyticsServiceApplication.class, args);
	}

}
